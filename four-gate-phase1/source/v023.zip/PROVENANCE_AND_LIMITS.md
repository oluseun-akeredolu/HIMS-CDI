# Corrected Phase I candidate — NOT the archived v0.2.9 run

- Created after independently re-executing the original archived generator on 31 October 2026.
- Original ZIP SHA-256: b0052e38da33b5733dcfb4b829a5472f4d15a109a8a67d6df7b053aa8ca5bafe.
- Original archived package preserved unmodified; this candidate has **no DOI** and is **NOT approved for submission**.
- Correction: avoid NumPy `<U4` truncation when copying PASS/FAIL item arrays by converting to object dtype before injecting UNKNOWN.
- 241 affected serialized item cells changed UNKN to UNKNOWN; all 240 eligibility labels unchanged.
- Full-input LR mean balanced accuracy changed from 0.803555556 to 0.902888889; sensitivity changed from 0.613333333 to 0.813333333.
- The corrected source passes 37/37 checks, including four new regression checks; the original 33/33 suite failed to detect the defect. A separate external check confirms all candidate item-state strings are canonical and 400 recomputed CV metric comparisons match.
- Rule-derived labels and synthetic parameters **do not** support predictions of real healthcare attacks, deployment, legal compliance or clinical effectiveness.
- Before release: review revised generator, add a regression test in the source, freeze protocol and hashes, obtain coauthor approval, and archive exact version with verified download-back. No historical source should be overwritten.
