# Phase I synthetic specification evaluation — v0.2.9

**Status:** new, explicitly specified synthetic evaluation; not a reconstruction of any earlier historical run.

## What this package is

This package tests a four-gate decision function on a synthetic corpus of 240 environments and 7,200 simulated execution records. It contains the generator, configuration, latent correlation matrix, environment/decision records, item-level evidence states, execution log, out-of-fold predictions, repeated-cross-validation summaries, robustness tables, verification checks and SHA-256 manifest.

## What this package is not

- It is not an empirical study of healthcare incidents or a live hospital deployment.
- It does not ingest actual CTI events or implement the entire CTI-to-evidence pipeline.
- Its scope-status distribution, indicator/control mappings, requirements, correlation matrix and resource equations are author-selected synthetic assumptions, not estimated real-world rates.
- All latency and memory measurements are simulated; no Raspberry Pi or other physical device was measured.
- The oracle merely re-emits labels defined by the same rule. Its perfect score is tautological and is not predictive evidence.
- The full-input logistic model receives gate-status features directly related to the outcome. Its metrics are rule-recovery diagnostics, not independent prediction of real attacks.
- Phase II has not been conducted. Real-world healthcare gate validity remains unresolved.
- The original historical generator and empirical dependence matrix were not recovered; these results must not be described as reproducing that run.

## Run details

- Run identifier: `HIMS-CDI-PhaseI-newrun-v0.2.9`
- Environments: 240
- Simulated repetitions/environment: 30
- Execution rows: 7,200
- Base measurement-noise model: mean-corrected lognormal multiplier, sigma 0.15
- Base evidence degradation for each PASS item: missing 0.05, stale 0.05, unreviewed 0.05
- Runtime gate: p95 latency < 200 ms and maximum memory < 100 MB
- Model protocol: ten repeats of stratified five-fold cross-validation; fixed threshold 0.50; same folds for comparator models
- Seed details are recorded in `config.json`.
- Verification: 33/33 checks passed.

## Principal descriptive results

- Observed-eligible environments: 15/240 (6.25%); 225/240 are not admissible.
- Clean pre-perturbation rule eligible environments: 96/240; agreement between clean and observed labels: 159/240 (66.25%). This is perturbation sensitivity within the synthetic rule, not independent validation.
- Resource-exceedance events: 1,274/7,200 latency readings (17.69%); 27/7,200 memory readings (0.38%); 1,296/7,200 readings with either exceedance (18.00%).
- Full-input logistic regression: mean balanced accuracy 0.804 (SD 0.027); sensitivity 0.613 (SD 0.053); specificity 0.994 (SD 0.003); macro-F1 0.851 (SD 0.026); AUROC 0.991 (SD 0.003); average precision 0.833 (SD 0.029).
- Six-domain model: balanced accuracy 0.500, sensitivity 0, specificity 1.000, macro-F1 0.484, AUROC 0.572 (SD 0.037), average precision 0.077 (SD 0.007).
- Equal-weight comparator: balanced accuracy 0.547, sensitivity 0.533, specificity 0.560, macro-F1 0.418, AUROC 0.563, average precision 0.088.
- Repeat-to-repeat SD describes fold-allocation variability over the same corpus, not confidence intervals or independent external validation.
- T1 eligible-set range: 2–32 across the 20 threshold combinations; base setting 15.
- T2 eligible counts under 0%, 5%, 10%, 20% *additional* evidence degradation: 15, 14, 10, 5.

See `summary_results.json`, `cv_metrics_summary.csv`, `cv_metrics_by_repeat.csv`, `threshold_sensitivity.csv`, `evidence_injection_sensitivity.csv` and `verification.txt` for exact values and denominators.

## Reproducibility

Use Python compatible with the versions in `requirements.txt`. To regenerate into a **new empty directory** (the script refuses to overwrite a nonempty output directory):

```bash
python phase1_newrun.py --out regenerated_output
```

The manifest contains file hashes except its own hash and records runtime versions. A rerun will have a different `created_at_utc` timestamp in `manifest.json`; generated non-manifest outputs should match byte-for-byte under the pinned environment. The script uses fixed random seeds; this does not make its modelling assumptions empirically valid.

## Release status

**Working release candidate — not yet public and not approved for submission.** No DOI is assigned to this exact package. Do not cite the older HIMS-CDI Zenodo record as this run. A public deposit must be created by an authorised project owner, downloaded back, and verified against the accompanying SHA-256 manifest before the manuscript is released.

## Citation and release identifier

A DOI for this exact version has not yet been assigned. After an authorised publication, use the DOI displayed on the new Zenodo version record only. Cite the DOI shown on the landing page for the exact deposited version; do not infer a DOI from a filename or from the existing HIMS-CDI Zenodo record. The existing HIMS-CDI Synthetic Data Archive (v1.5.4) is a separate pipeline and is not this experiment.


## Comparator feature interpretation

The restricted logistic comparator uses six continuous mean-indicator aggregates rescaled to 0–5. These are not discretised ordinal anchor categories and are not a literal implementation of the HIMS ordinal decision layer. The restricted model and the equal-weight aggregate are analytic baselines only; neither determines gate eligibility. The principal Phase I claim remains the declared four-gate rule’s simulated behaviour, not clinical prediction.
