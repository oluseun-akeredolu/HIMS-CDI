# Phase I protocol and analysis record — v0.2

**Date:** 27 October 2026  
**Status:** versioned protocol documented before execution of v0.2, after inspection of candidate v0.1 outputs and historical claims; not preregistered or blinded.

## Research target

Test whether the coded four-gate function implements the declared logical specification on a synthetic corpus, and describe how its admissible set and simple comparison functions behave under declared measurement/evidence perturbations. The experiment does not estimate live-healthcare effectiveness.

## Gate rules

- G1 scope: synthetic scope records carry boundary, jurisdiction, control registry, rationale and conflict fields. Scope state mix is an analyst-selected scenario (90% PASS, 5% FAIL, 5% UNKNOWN at the design level), not an empirical rate.
- G2 evidence: six measured control proxies. A measured numeric threshold failure is FAIL. Evidence degradation may turn a passing item into UNKNOWN.
- G3 operational scenario: p95 latency < 200 ms and maximum of 30 memory values < 100 MB; a measured violation is FAIL. All readings are simulated.
- G4 other requirements: two declared proxies (REQ-A and REQ-B); measured threshold failure is FAIL, and degraded/unverifiable passing evidence may become UNKNOWN.
- Conjunction: FAIL dominates UNKNOWN; otherwise any UNKNOWN yields UNKNOWN; all PASS yields PASS. Eligibility requires all four gates PASS.

## Data generation and perturbation

- 240 environments; 20 continuous synthetic indicators in six groups.
- Latent factor model: global-factor variance 0.05, domain-factor variance 0.20, residual variance 0.75; implied pairwise correlation 0.25 within domains and 0.05 across domains.
- Seeds are in `config.json`; all six separate seed roles are explicit.
- Dwell-time scenario target mean 62 days and SD 28 days; this is not presented as an empirical healthcare estimate.
- Thirty lognormal-noise latency and memory repetitions/environment, sigma 0.15.
- Base evidence degradation on each PASS G2/G4 item: missing/stale/unreviewed each at probability 0.05; FAIL stays FAIL.
- Additional degradation scenarios 0%, 5%, 10% and 20% per passing item, layered on top of the base schedule.
- Runtime thresholds 200 ms and 100 MB are analyst-selected scenario parameters, not universal standards.

## Model comparison

- Observed label: four-gate rule applied after evidence degradation and simulated resource readings.
- Ten repeats of stratified five-fold CV on the 240 environments; same folds for all comparators. The CV split seed starts at 46 and increments per repeat.
- Scaling fitted inside training folds; logistic regression C=1.0, lbfgs, 2,000 maximum iterations.
- Full-input logistic model uses status indicators for G1, six G2 controls and two G4 requirements plus p95 latency and peak memory (29 features). Those features are related directly to the outcome rule, so its scores are rule-recovery diagnostics rather than independent prediction.
- Restricted logistic model uses six continuous domain aggregates (indicator means rescaled to 0–5); they are not discretised into the manuscript rubric's ordinal anchor categories. This is a numeric baseline diagnostic, not an ordinal decision model. The fixed equal-weight aggregate comparator uses a 0.50 threshold and likewise serves only as an analytic baseline.
- Classification threshold fixed at 0.50; no test-threshold optimisation or probability calibration.
- Oracle only re-emits the labels and is a tautological identity check.

## Reporting

Report exact counts and balanced accuracy, sensitivity, specificity, macro-F1, AUROC and average precision. Report mean, sample SD, minimum and maximum across repeats. The SD describes variation in fold allocation on the same dataset, not a confidence interval. The positive class is only 15/240; interpret sensitivity and average precision cautiously.

## Verification and reproducibility

The generator runs 33 code/data checks, including status semantics, strict boundary behavior, correlation matrix validity, denominators, output dimensions, eligible gate conjunction and sensitivity monotonicity. The same script was run independently a second time; all 14 non-manifest output files matched byte-for-byte. This demonstrates computational determinism under the tested runtime, not validity of synthetic assumptions.

## Limitations and claims boundary

No real incident data, live CTI objects, hospital workflow, clinician evaluation, or physical target-device resource measurement is present. Phase I-E calibration results are separate and were not regenerated as part of this run. Phase II is uncompleted. Real-world gate validity remains unresolved. The original historical generator and empirical matrix were not recovered; this run is distinct and must not be described as historical reproduction.
