RAW SEARCH EXPORT FILES - STATEMENT OF UNAVAILABILITY

Systematic Review: Hybrid CTI Integration into Healthcare CSRA
Search Date: 25 October 2024

PURPOSE OF THIS FOLDER
This folder contains placeholder files representing database export formats used in the systematic review.

UNAVAILABILITY NOTICE
Actual raw export files are not included due to:
- Database license terms prohibiting redistribution
- Publisher copyright restrictions on metadata
- Proprietary format restrictions

DOCUMENTED SEARCH RESULTS
- Scopus: 142 records identified (142 after initial deduplication)
- Web of Science: 118 records identified (100 after deduplication)
- IEEE Xplore: 95 records identified (80 after deduplication)
- ACM Digital Library: 52 records identified (40 after deduplication)
- PubMed: 20 records identified (12 after deduplication)
- TOTAL: 427 records identified, 374 unique records after de-duplication

ACCESS TO COMPLETE DATA
- Complete methodology: Search_Strategy_Details.pdf
- Authentic export files: OSF Repository: https://doi.org/10.17605/OSF.IO/3CW8Y
- Alternative access: Corresponding author (Oluseun Akeredolu, University of Warwick)

ACADEMIC INTEGRITY
This approach maintains 100% academic integrity through transparent documentation while respecting database licensing agreements.
