S3 STATISTICAL VALIDATION FOLDER
================================

This folder contains supplementary materials for Section S3:
"Statistical Validation of Proportional Estimates"

CONTENTS:
1. S3_main_document.docx - Explanatory text and methodology
2. Table_S3.csv - Statistical stability of paradigm proportions
3. Table_S4.csv - Q1-Only vs. Full Corpus sensitivity comparison  
4. Table_S5.csv - Key proportion confidence intervals from main text
5. Table_S6.pdf - Clinical Hardware Constraints Relevant to Edge Deployment
6. Table_S7.pdf - Failure Mode Prevalence and Clinical Impact Assessment


FORMAT:
- CSV files for data tables (compatible with Excel, R, Python)
- Document file for explanatory text

USE:
These materials supplement the systematic review's statistical
transparency and uncertainty quantification procedures.

Last updated: 7 October 2025