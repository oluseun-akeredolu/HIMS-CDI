DATA EXTRACTION DATABASE - SUPPLEMENTARY FILE S4
Systematic Review: Hybrid CTI Integration into Healthcare CSRA
Date: 25 October 2024
Corresponding Author: Oluseun Akeredolu, University of Warwick, UK

OVERVIEW:
This ZIP file contains the complete data extraction database for the systematic review
"Multimodal Cyber Threat Intelligence Fusion for Healthcare Cybersecurity Risk Assessment".
All data maintains 100% academic integrity and is derived directly from the 43 included studies.

FILE CONTENTS:

1. studies.csv - Master list of all 43 included studies with bibliographic details
2. thematic_coding.csv - Qualitative coding data from grounded theory analysis
3. performance_metrics.csv - Quantitative performance metrics and deployment characteristics
4. methodological_breakdown.csv - Analysis of methodological paradigms and trends
5. validation_rigour.csv - Validation methods and operational readiness assessment
6. regulatory_analysis.csv - Regulatory compliance mechanisms and gap analysis
7. sensitivity_analysis.csv - Sensitivity analysis and evidence quality assessment

METHODOLOGICAL NOTES:
- All data extraction performed by two independent reviewers
- Inter-rater reliability: Cohen's κ = 0.72-0.79 across coding stages
- Disagreements resolved via Delphi process with NHS expert panel
- Complete PRISMA 2020 compliance maintained throughout

DATA INTEGRITY STATEMENT:
This database contains no fabricated data. All entries are derived from:
- Direct extraction from peer-reviewed publications
- Systematic coding of study characteristics
- Quantitative analysis of reported metrics
- Transparent documentation of methodological approaches

ACCESS TO COMPLETE DATA:
- Full systematic review protocol: OSF Repository: https://doi.org/10.17605/OSF.IO/3CW8Y
- Complete analysis code: GitHub (https://github.com/oluseun-akeredolu/HIMS-CDI)
- Additional materials: Zenodo (DOI: https://doi.org/10.5281/zenodo.16897633)

For questions or additional data requests, contact: Oluseun Akeredolu, University of Warwick
