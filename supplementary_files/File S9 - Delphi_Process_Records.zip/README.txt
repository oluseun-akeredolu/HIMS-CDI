﻿DELPHI PROCESS DOCUMENTATION - FILE S9

This archive contains documentation for the Delphi process described in:
Akeredolu, O., Maple, C., & Epiphaniou, G. (2024). 
Multimodal Cyber Threat Intelligence Fusion for Healthcare Cybersecurity Risk Assessment: A Systematic Review.

The Delphi process was used exclusively to resolve screening disagreements during the systematic review process as described in Section 2.

Contents:
1. Delphi_Process_Description.pdf - Brief description of Delphi process
2. Expert_Panel_Composition.csv - Expert panel details

Alignment Note: This documentation contains ONLY information explicitly described in the manuscript. 
No additional methodological details, questionnaires, or results beyond what is stated in the text are included.

References:
- Manuscript Section 2: Methodology
- Manuscript Section 2.4: Expert Consensus Validation

Related Documentation:
- Supplementary Table S3: Methodological consistency tracking
- Supplementary Material S10: Methodological transparency documentation