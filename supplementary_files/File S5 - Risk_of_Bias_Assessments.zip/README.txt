================================================================================
SUPPLEMENTARY FILES S5: RISK OF BIAS ASSESSMENTS
Systematic Review: Multimodal Cyber Threat Intelligence Fusion for 
Healthcare Cybersecurity Risk Assessment
================================================================================
Date: 25 October 2024 | Protocol Version: 1.0
Corresponding Author: Oluseun Akeredolu, University of Warwick, UK
OSF Repository: https://doi.org/10.17605/OSF.IO/3CW8Y

CONTENTS:
risk_of_bias_assessments.csv (Detailed bias assessments for 43 studies)
quality_appraisal_protocol.pdf (Modified ROBIS tool methodology)
README.txt (This file)

OVERVIEW:
This supplementary file contains comprehensive risk-of-bias assessments for all 
43 studies included in the systematic review, using a modified ROBIS tool 
adapted for cybersecurity research in healthcare contexts. The package now includes both raw assessment data and a detailed analytical report.

METHODOLOGICAL INTEGRITY:
Dual Independent Review: Two reviewers assessed each study independently
Inter-rater Reliability: Cohen's κ = 0.77 overall across all domains
Expert Validation: NHS cybersecurity panel consensus for clinical relevance
Structured Process: Pre-screening calibration (κ = 0.85) and conflict resolution

DOMAIN STRUCTURE:
1. STUDY ELIGIBILITY CRITERIA - Appropriateness of selection criteria
2. IDENTIFICATION & SELECTION - Comprehensiveness of search and selection  
3. DATA COLLECTION & APPRAISAL - Rigor in data extraction and quality assessment
4. SYNTHESIS & FINDINGS - Transparency and appropriateness of analysis

RISK CLASSIFICATIONS:
LOW RISK    - Robust methodology with minimal bias concerns
MEDIUM RISK - Some methodological limitations affecting confidence  
HIGH RISK   - Significant methodological flaws affecting validity

DISTRIBUTION SUMMARY:
Low Risk Studies: 16/43 (37.2%)
Medium Risk Studies: 17/43 (39.5%)
High Risk Studies: 10/43 (23.3%)

DETAILED FINDINGS (See Supplementary File S5):
- High-Risk Studies Analysis: 10 studies with critical methodological flaws
- Medium-Risk Studies: 17 studies with moderate limitations
- Low-Risk Exemplars: 16 studies demonstrating robust methodology
- Common Weaknesses: Limited search documentation, single reviewer extraction, inadequate limitations discussion
- Cybersecurity Adaptations: Technical validation, healthcare compliance, operational feasibility

VALIDATION MEASURES:
- Taxonomy Stability: Maintained across risk levels (κ = 0.85)
- Framework Robustness: Conclusions consistent across risk strata
- Clinical Relevance: NHS expert panel validation incorporated
- Inter-Rater Reliability: Substantial agreement across all domains (κ = 0.71-0.82)

FILE COMPLEMENTARITY:
- risk_of_bias_assessments.csv: Raw assessment data for independent verification
- quality_appraisal_protocol.pdf: Methodology and assessment criteria
- Together these files provide complete transparency and reproducibility

CONTACT:
Corresponding Author: Oluseun Akeredolu
Affiliation: Secure Cyber Systems Research Group, WMG, University of Warwick
Email: Olu.Akeredolu@warwick.ac.uk
Repository: https://doi.org/10.17605/OSF.IO/3CW8Y

================================================================================

