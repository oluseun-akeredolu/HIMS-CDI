#!/usr/bin/env python3
import numpy as np
A = np.array([
[1.0,1.0,0.5,1.0,0.5,1.0],
[1.0,1.0,0.5,1.0,0.5,1.0],
[2.0,2.0,1.0,2.0,1.0,2.0],
[1.0,1.0,0.5,1.0,0.5,1.0],
[2.0,2.0,1.0,2.0,1.0,2.0],
[1.0,1.0,0.5,1.0,0.5,1.0]
])
n=A.shape[0]
eigvals,eigvecs=np.linalg.eig(A)
lambda_max=np.max(eigvals.real)
vec=eigvecs[:,np.argmax(eigvals.real)].real
weights=vec/np.sum(vec)
CI=(lambda_max-n)/(n-1)
RI=1.24
CR=CI/RI
print(lambda_max,CI,CR,weights)
