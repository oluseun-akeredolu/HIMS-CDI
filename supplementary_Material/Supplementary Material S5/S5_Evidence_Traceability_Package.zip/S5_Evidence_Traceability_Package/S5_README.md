# S5 Evidence Traceability Package

## Contents

* `traceability\_schema.json`
JSON Schema (draft-07) for a single traceability record.
* `examples/gnn\_seed13\_best.json`
Example trace for the best validation epoch of the GNN model with seed 13.
* `examples/hims\_cdi\_mlr\_seed37.json`
Example trace for the HIMS-CDI MLR model at its final training epoch.
* `S5\_clause\_list.json` – Complete enumeration of 27 regulatory clauses (GDPR, HIPAA, NHS DSPT) with artefact mappings for CCR calculation.

## Purpose

This package enables automated verification of reported experimental results by linking each claim to its data source, execution parameters, and the exact location of the raw data.

